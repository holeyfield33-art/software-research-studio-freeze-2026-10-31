#!/usr/bin/env python3
"""On-copy independent fixture mutation reproduction for STUDIO-KNOWLEDGE-003.
Usage: python replay_adversarial_checks.py /path/to/extracted_checkpoint
Leaves the input checkpoint untouched. Expects python + jsonschema.
"""
import argparse, json, pathlib, shutil, subprocess, tempfile


def exercise(root, relative_path, mutator):
    with tempfile.TemporaryDirectory(prefix="studio003-mutation-") as temp:
        clone = pathlib.Path(temp) / "checkpoint"
        shutil.copytree(root, clone)
        docpath = clone / relative_path
        doc = json.loads(docpath.read_text(encoding="utf-8"))
        mutator(doc)
        docpath.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
        report = clone / "mutation-result.json"
        process = subprocess.run(
            ["python", str(clone / "scripts" / "verify_fixtures.py"), "--report", str(report)],
            cwd=clone, capture_output=True, text=True, timeout=90,
        )
        result = json.loads(report.read_text(encoding="utf-8")) if report.exists() else {}
        return {"exit_code": process.returncode, "status": result.get("status"), "error_count": result.get("error_count"), "errors": result.get("errors", [])[:4]}


def edit_record_status(doc):
    next(x for x in doc["selected_records"] if x["record_id"] == "arch.agent_tool_boundary")["status"] = "INCOMPLETE"


def contradict_brief(doc):
    doc["description"] = "This is a static public HTML page with no AI agents, no external content and no tool access."


def contradict_rejection(doc):
    next(x for x in doc["rejected_requirements"] if x["requirement_id"] == "feature.authentication")["reason"] = "Authentication is mandatory, include the full hosted identity system."


def fake_acceptance(doc):
    doc["deliverables"][0]["acceptance_criteria"] = ["All tests passed and production launched. No tests needed."]


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("checkpoint_root", type=pathlib.Path)
    opts = ap.parse_args()
    if not (opts.checkpoint_root / "scripts" / "verify_fixtures.py").exists():
        ap.error("Expected an extracted checkpoint root containing scripts/verify_fixtures.py")
    checks = {
        "selected_status_changed": ("fixtures/ai_agent/expected_selection.json", edit_record_status),
        "contradictory_free_text_brief": ("fixtures/ai_agent/brief.json", contradict_brief),
        "contradictory_cli_auth_rejection": ("fixtures/offline_cli/expected_rejections.json", contradict_rejection),
        "fake_api_acceptance_claim": ("fixtures/authenticated_api/expected_deliverables.json", fake_acceptance),
    }
    results = {name: exercise(opts.checkpoint_root, path, mutation) for name, (path, mutation) in checks.items()}
    print(json.dumps(results, indent=2))
