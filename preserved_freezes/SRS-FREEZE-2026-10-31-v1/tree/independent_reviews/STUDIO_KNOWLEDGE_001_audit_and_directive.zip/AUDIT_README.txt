Audit of initial STUDIO knowledge checkpoint
Original ZIP SHA256: 30a2cd7746064c36ea24b7e43c302942db6e10b674edcc06de7ced7f97a4732c
Draft 2020-12 independently validated with jsonschema: 45/45 records passed.
This pack does not modify the original checkpoint.
