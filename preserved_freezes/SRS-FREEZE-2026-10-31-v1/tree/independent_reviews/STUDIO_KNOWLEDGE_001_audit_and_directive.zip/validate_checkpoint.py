#!/usr/bin/env python3
"""Non-destructive validation of STUDIO-KNOWLEDGE-001 v1 JSONL checkpoint.

Usage: python validate_checkpoint.py /path/to/STUDIO_KNOWLEDGE_001
Requires: jsonschema (pip install jsonschema)
Writes no data; prints a machine-readable JSON audit summary.
"""
import argparse
import collections
import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

PARTITIONS = [
    'software_types','engineering_practices','sdlc_stages',
    'architecture_patterns','prompt_patterns','roadmap_patterns',
    'verification_gates','reference_projects','sources','relationships'
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path, help='Extracted STUDIO_KNOWLEDGE_001 directory')
    args = parser.parse_args()
    root = args.root
    errors = []
    warnings = []
    records = {}
    for name in PARTITIONS:
        path = root / 'dataset' / 'v1' / (name + '.jsonl')
        if not path.exists():
            errors.append(f'Missing partition: {path}')
            records[name] = []
            continue
        records[name] = []
        for line, raw in enumerate(path.read_text(encoding='utf-8').splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                record = json.loads(raw)
                if not isinstance(record, dict):
                    raise ValueError('Expected JSON object')
                records[name].append(record)
            except (json.JSONDecodeError, ValueError) as exc:
                errors.append(f'{name}:{line}: {exc}')
        if not records[name]:
            warnings.append(f'UNPOPULATED_PARTITION: {name}')

    validators = {}
    for role in ['knowledge', 'source']:
        path = root / 'schemas' / f'{role}-record.schema.json'
        try:
            schema = json.loads(path.read_text(encoding='utf-8'))
            Draft202012Validator.check_schema(schema)
            validators[role] = Draft202012Validator(schema, format_checker=FormatChecker())
        except Exception as exc:
            errors.append(f'Invalid or unavailable {role} schema: {exc}')

    ids = {}
    for partition, items in records.items():
        for row_no, rec in enumerate(items, 1):
            loc = f'{partition}:{row_no}'
            rid = rec.get('id')
            if not isinstance(rid, str) or not rid:
                errors.append(f'{loc}: invalid/missing id')
            elif rid in ids:
                errors.append(f'{loc}: duplicate id {rid}, previously {ids[rid]}')
            else:
                ids[rid] = loc
            # Relationships need a dedicated schema; avoid pretending that
            # the generic knowledge envelope will validate typed edges.
            if partition == 'relationships':
                if items:
                    warnings.append('RELATIONSHIP_SCHEMA_MISSING: typed edge schema not supplied')
                continue
            v = validators.get('source' if partition == 'sources' else 'knowledge')
            if v:
                for err in v.iter_errors(rec):
                    errors.append(f'{loc}: JSON Schema: {err.message} ({list(err.path)})')
            if partition not in ('sources', 'relationships') and rec.get('knowledge_category') != partition:
                errors.append(f'{loc}: category mismatch')

    source_ids = {r.get('id') for r in records['sources']}
    type_ids = {r.get('id') for r in records['software_types']}
    slug_ids = {str(x).removeprefix('software_type.') for x in type_ids}
    for partition, items in records.items():
        if partition in ('sources','relationships'):
            continue
        for rec in items:
            rid = rec.get('id')
            for sid in rec.get('source_ids', []):
                if sid not in source_ids:
                    errors.append(f'{rid}: unresolved source_id: {sid}')
            for target in rec.get('related_record_ids', []):
                if target not in ids:
                    errors.append(f'{rid}: unresolved related_record_id: {target}')
            for typ in rec.get('applicable_software_types', []):
                if typ not in type_ids and typ not in slug_ids:
                    errors.append(f'{rid}: unknown applicable_software_type: {typ}')

    sources = records['sources']
    for source in sources:
        if source.get('publisher') == 'See source page':
            warnings.append(f'SOURCE_METADATA_PLACEHOLDER: {source.get("id")}')
        if 'confirm per page' in source.get('source_kind', ''):
            warnings.append(f'SOURCE_KIND_UNVERIFIED: {source.get("id")}')
        if '/main/' in source.get('url','') or source.get('url','').endswith('/main'):
            warnings.append(f'UNPINNED_MAIN_BRANCH: {source.get("id")}')
    for rec in records['software_types']:
        if rec.get('recommended_actions_or_practices') == [rec.get('description')]:
            warnings.append(f'ACTION_REPEATS_DESCRIPTION: {rec.get("id")}')
        if not rec.get('related_record_ids'):
            warnings.append(f'NO_RECORD_RELATIONS: {rec.get("id")}')
    path = root / 'build_seed.py'
    if path.exists() and 'open(f\'{base}/{name}.jsonl\',\'w\')' in path.read_text():
        warnings.append('DESTRUCTIVE_SEED_SCRIPT: build_seed.py overwrites JSONL partitions')

    result = {
        'status': 'PASS_WITH_WARNINGS' if not errors else 'FAIL',
        'validation_mode': 'Draft 2020-12 + format check + cross-reference checks',
        'records_by_partition': {k: len(v) for k,v in records.items()},
        'validated_records': sum(map(len, records.values())),
        'errors': errors,
        'warnings': warnings,
        'warning_counts_by_type': dict(collections.Counter(w.split(':',1)[0] for w in warnings)),
    }
    print(json.dumps(result, indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
