import json,subprocess,sys,tempfile
from pathlib import Path
root=Path('/mnt/data/studio003r_audit/input')
base=json.loads((root/'selection_cases/base_ai_agent/brief.json').read_text())
samples={}
a=json.loads(json.dumps(base));a['facts']=['bad-fact-row'];samples['malformed_fact_row']=a
b=json.loads(json.dumps(base));b['facts']='not-an-array';samples['malformed_facts_field']=b
c=json.loads(json.dumps(base));
for f in c['facts']:
 if f['fact_id'] in ['reads_untrusted_external_content','has_read_access','has_bounded_write_tool','can_cause_side_effects','high_impact_action_possible','approval_required_for_high_impact']:f['state']='false'
samples['agent_without_tools_or_untrusted_content']=c
d=json.loads(json.dumps(base));d['facts'].append(dict(d['facts'][0],state='false' if d['facts'][0]['state']=='true' else 'true'))
samples['duplicate_contradictory_fact']=d
out=[]
with tempfile.TemporaryDirectory() as tmp:
 for n,brief in samples.items():
  p=Path(tmp)/f'{n}.json';p.write_text(json.dumps(brief));o=Path(tmp)/f'out_{n}'
  x=subprocess.run([sys.executable,str(root/'scripts/select.py'),'--brief',str(p),'--dataset',str(root/'dataset/v1'),'--rules',str(root/'rules/selection-rules.json'),'--out',str(o)],text=True,capture_output=True,timeout=25)
  q={'case':n,'exit_code':x.returncode,'exception':x.stderr.strip().splitlines()[-1] if x.returncode and x.stderr else None}
  if x.returncode==0:
   s=json.loads((o/'selection.json').read_text());r=json.loads((o/'rejections.json').read_text())
   q.update({'overall':s['overall_decision']['status'],'conflicts':r['conflicting_fact_ids'],'schema_error_count':len(r['schema_errors']),'selected_count':len(s['selected_records']),'selected_agent_boundary':next(({'status':i['status'],'rule_id':i['rule_id']} for i in s['selected_records'] if i['record_id']=='arch.agent_tool_boundary'),None),'selected_prompt_threat':any(i['record_id']=='prompt.threat_model' for i in s['selected_records'])})
  out.append(q)
print(json.dumps(out,indent=2))
Path('/mnt/data/studio003r_audit/adversarial_results_extended.json').write_text(json.dumps(out,indent=2)+'\n')
