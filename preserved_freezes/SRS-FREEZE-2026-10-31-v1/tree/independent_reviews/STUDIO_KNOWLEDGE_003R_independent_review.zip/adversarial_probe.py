#!/usr/bin/env python3
import json,subprocess,sys,tempfile,copy
from pathlib import Path
root=Path('/mnt/data/studio003r_audit/input')
scenarios={
 'queue_fully_justified':('api_queue_without_justification',{'queue_load_justification':'true','operations_owner_available':'true'},{}),
 'cli_upload_authorized_and_destination_known':('cli_network_upload_unknown_scope',{'network_upload_authorized':'true','upload_destination_known':'true'},{}),
 'cli_destructive_flag_authorized':('cli_destructive_overwrite_unauthorized',{'destructive_write_authorized':'true'},{}),
 'api_auth_dependency_conflict':('base_authenticated_api',{'public_read_only':'true','authentication_required':'false','role_based_authorization':'false'},{}),
}
results=[]
with tempfile.TemporaryDirectory() as d:
 for name,(base,changes,extras) in scenarios.items():
  b=json.loads((root/'selection_cases'/base/'brief.json').read_text())
  for f in b['facts']:
   if f['fact_id'] in changes:f['state']=changes[f['fact_id']]
  p=Path(d)/f'{name}.json';p.write_text(json.dumps(b))
  o=Path(d)/name
  proc=subprocess.run([sys.executable,str(root/'scripts/select.py'),'--brief',str(p),'--dataset',str(root/'dataset/v1'),'--rules',str(root/'rules/selection-rules.json'),'--out',str(o)],capture_output=True,text=True,timeout=25)
  if proc.returncode:
   results.append({'name':name,'error':proc.stderr[:300]});continue
  sel=json.loads((o/'selection.json').read_text());rej=json.loads((o/'rejections.json').read_text())
  hit=[x for x in rej['feature_decisions'] if x['decision_id'] in ('feature.queue','feature.network_upload','feature.destructive_overwrite','feature.authentication','feature.authorization')]
  record_hit=[x for x in rej['rejected_records'] if x['record_id'] in ('arch.event_queue','arch.multitenancy_isolation')]
  results.append({'name':name,'overall_status':sel['overall_decision']['status'],'relevant_feature_decisions':hit,'rejected_records':record_hit,'facts_modified':changes})
Path('/mnt/data/studio003r_audit/adversarial_results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
