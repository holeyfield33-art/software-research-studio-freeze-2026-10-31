# Validation report — initial seed

Validation date: 2026-10-30. Scope: seeded `software_types.jsonl` and `sources.jsonl`; empty partitions are intentionally not data records. The environment lacks the `jsonschema` Python package and package installation did not succeed, so this is a dependency-free structural validation (required keys, unexpected keys, basic JSON types/enums, and source-reference integrity), not a full JSON Schema implementation check.

- Records structurally checked: 45
- Validation errors: 0
- Structural result: PASS
- Full Draft 2020-12 validation: pending an available validator.
- This is an initial-seed report, not whole-dataset validation.
