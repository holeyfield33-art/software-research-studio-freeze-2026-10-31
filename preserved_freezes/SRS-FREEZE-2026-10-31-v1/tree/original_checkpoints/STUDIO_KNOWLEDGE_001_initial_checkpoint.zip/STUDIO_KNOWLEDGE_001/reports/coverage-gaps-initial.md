# Coverage-gap analysis — initial seed

Adequately represented only at the category-overview level: web applications, SaaS, APIs/web services, mobile applications, CLI tools, developer tools, AI agents, security products, data pipelines, and libraries/SDKs. This does not mean that any category has enough depth for reliable generator outputs.

Not yet researched or recorded as structured knowledge: lifecycle/process models and applicability; approval gates and stage deliverables; testing strategies across risk levels; security controls and release/maintenance workflows; cross-cutting architecture patterns and tradeoffs; reusable prompt templates with variables, output contracts, approvals, and verification; milestone/dependency/acceptance-criteria patterns; detailed reference-project structures and actual agent instructions; explicit relationships among requirements, practices, stages, gates, roadmap items, prompts, deliverables, and evidence.

Additional research should use versioned primary standards and first-party project documentation, then inspect pinned repository files and CI/test/release configurations. Conflicts and domain-specific exceptions need explicit records. The seed is not sufficient to generate project-specific SDLCs, coding prompts, or roadmaps reliably.
