# Data dictionary — STUDIO-KNOWLEDGE-001

Dataset schema version: 1.0.0. JSONL files contain one JSON object per line; UTF-8. Empty files indicate not yet researched, not that the concept is inapplicable.

- `id`: Stable namespaced identifier; do not recycle.
- `version`: Semantic record version.
- `knowledge_category`: One of the ten dataset partitions.
- `applicable_software_types`: Software category IDs for which the record may apply.
- `preconditions_and_exclusions`: When to use, qualify, or omit the record.
- `required_inputs`: Context needed before applying the practice.
- `recommended_actions_or_practices`: Conditional action guidance, not universal mandates.
- `dependencies`: Prerequisite decisions, components, or records.
- `expected_deliverables`: Artifacts/evidence expected if adopted.
- `verification_requirements`: How to verify implementation or result.
- `known_failure_modes`: Known risks or common failure patterns.
- `source_ids`: Foreign keys into sources.jsonl.
- `evidence_classification`: Documented guidance, observed implementation, tested outcome, or inference; distinguish them.
- `confidence`: Qualitative confidence in applicability and evidence support.
- `limitations`: Scope and uncertainty.
- `related_record_ids`: Cross-record relations; currently incomplete.
