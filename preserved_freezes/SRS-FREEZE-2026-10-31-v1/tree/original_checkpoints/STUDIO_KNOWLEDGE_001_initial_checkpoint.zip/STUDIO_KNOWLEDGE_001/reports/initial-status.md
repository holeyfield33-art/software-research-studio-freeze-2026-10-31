# Initial research status

Seeded version 1.0.0 with ten software-type overview records: web applications, SaaS, APIs, mobile applications, CLI tools, developer tools, AI agents, security products, data pipelines, and libraries/SDKs. Each record carries source IDs and conditional guidance. URLs are captured; detailed per-source title/publisher/claim mappings and source-revision tracking still need normalization.

Not yet populated: engineering practices, SDLC stages, architecture patterns, prompt patterns, roadmap patterns, verification gates, reference-project records, and explicit relationships. Therefore this is an initial research dataset, not the complete requested archive. No Studio, Block-Wise, product, or repository was modified.
