#!/usr/bin/env python3
"""Build and verify the immutable research-only 003 ZIP checkpoint."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def run(args):
 p=subprocess.run(args,cwd=ROOT,capture_output=True,text=True)
 if p.returncode: raise SystemExit(f"Command failed ({p.returncode}): {' '.join(map(str,args))}\n{p.stdout}\n{p.stderr}")
 return p.stdout

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--archive',default='/home/ubuntu/STUDIO_KNOWLEDGE_003_checkpoint.zip');args=ap.parse_args();archive=Path(args.archive).resolve()
 run([sys.executable,'scripts/validate_dataset.py','--report','reports/dataset-validation.json'])
 run([sys.executable,'scripts/verify_fixtures.py','--report','reports/fixture-validation.json'])
 run([sys.executable,'scripts/run_regression_tests.py'])
 run([sys.executable,'scripts/build_version_map.py'])
 run([sys.executable,'scripts/build_003_reports.py'])
 for p in ROOT.rglob('*.tmp'):
  if p.is_file():p.unlink()
 allowed=['README.md','dataset','schemas','fixtures','tests','scripts','reports','research']
 files=[]
 for item in allowed:
  p=ROOT/item
  if not p.exists():continue
  if p.is_file(): candidates=[p]
  else: candidates=[q for q in p.rglob('*') if q.is_file()]
  for q in candidates:
   rel=q.relative_to(ROOT).as_posix()
   if '__pycache__' in q.parts or q.suffix in ('.pyc','.tmp') or q.name.endswith('.zip'): continue
   files.append(q)
 files=sorted(set(files),key=lambda p:p.relative_to(ROOT).as_posix())
 if not files:raise SystemExit('No package files found')
 for p in files:
  if p.name.endswith('.zip') or p.suffix in ('.pyc','.tmp') or '__pycache__' in p.parts:raise SystemExit('Forbidden package artifact: '+str(p))
 dataset_report=json.loads((ROOT/'reports/dataset-validation.json').read_text());fixture_report=json.loads((ROOT/'reports/fixture-validation.json').read_text());test_report=json.loads((ROOT/'reports/regression-tests.json').read_text())
 if any(r.get('status')!='PASS' for r in (dataset_report,fixture_report,test_report)):raise SystemExit('Refusing to package non-PASS validation state')
 members={p.relative_to(ROOT).as_posix():sha(p) for p in files if p.name not in ('manifest.json','manifest.sha256')}
 manifest={'project':'STUDIO-KNOWLEDGE-003','dataset_version':dataset_report['dataset_version'],'schema_version':dataset_report['schema_version'],'build_date_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'research-only data, schema and fixture QA; no Studio integration','validation_status':'PASS','fixture_status':'PASS','regression_tests':test_report['tests_run'],'original_checkpoint_zips_embedded':False,'sha256':members}
 mpath=ROOT/'manifest.json';mpath.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 mhash=sha(mpath);(ROOT/'manifest.sha256').write_text(f'{mhash}  manifest.json\n',encoding='utf-8')
 verifier=[sys.executable,'scripts/verify_manifest.py','--root',str(ROOT)]
 pre=json.loads(run(verifier))
 if pre['status']!='PASS':raise SystemExit('In-tree manifest check failed: '+json.dumps(pre))
 archive.parent.mkdir(parents=True,exist_ok=True)
 if archive.exists():archive.unlink()
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for rel in sorted(set(members)|{'manifest.json','manifest.sha256'}): z.write(ROOT/rel,arcname=rel)
 archive_hash=sha(archive);Path(str(archive)+'.sha256').write_text(f'{archive_hash}  {archive.name}\n',encoding='utf-8')
 post=json.loads(run(verifier+['--archive',str(archive)]))
 if post['status']!='PASS':raise SystemExit('Final archive check failed: '+json.dumps(post))
 result={'status':'PASS','archive':str(archive),'archive_sha256':archive_hash,'archive_size_bytes':archive.stat().st_size,'manifest_sha256':mhash,'manifest_file_count':len(members),'record_count':dataset_report['record_count'],'active_edges':dataset_report['counts']['active_relationship_count'],'fixtures':fixture_report['fixture_count'],'regression_tests':test_report['tests_run'],'validation_errors':dataset_report['error_count']+fixture_report['error_count'],'original_archives_embedded':False,'verifier':post}
 print(json.dumps(result,indent=2,ensure_ascii=False));return 0
if __name__=='__main__':sys.exit(main())
