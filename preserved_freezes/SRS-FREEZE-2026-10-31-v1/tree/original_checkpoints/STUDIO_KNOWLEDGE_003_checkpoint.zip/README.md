# STUDIO-KNOWLEDGE-003 — research-only calibration

This checkpoint converts 002’s paper examples into data-only, replayable acceptance fixtures. It adds typed schemas, graph/provenance validation, three narrow software briefs, a separate negative-control branch, and a regression suite. It does **not** implement a product generator or modify Studio.

## Contents

- `dataset/v1/` — versioned knowledge, source, and typed relationship JSONL.
- `schemas/` — Draft 2020-12 contracts, including category-specific shapes.
- `fixtures/ai_agent/`, `fixtures/authenticated_api/`, `fixtures/offline_cli/` — the three acceptance fixtures. `fixtures/conflict_missing_evidence/` holds machine-readable abstention controls.
- `fixtures/golden-id-map.json` — exact selected/rejected ID oracle.
- `scripts/verify_fixtures.py` — read-only fixture checker entry point (writes only its JSON report, never the dataset).
- `scripts/validate_dataset.py` — schema, graph, source, applicability and roadmap-DAG validation.
- `tests/` — preservation, mutation, source-import/migration idempotency, negative-control and manifest tests.
- `reports/graph-coverage.md`, `reports/source-claim-review.csv`, `reports/failed-negative-controls.md`, `reports/decision.md` and `reports/validation-report.json` — scope and acceptance results.
- `research/record-index-001.json`, `research/record-index-002.json`, and `research/immutable-input-digests.json` — compact stable-ID/hash evidence; original ZIPs are not embedded.

## Reproduce validation

Requires Python 3.10+ and `jsonschema` with Draft 2020-12 support.

```bash
python3 scripts/validate_dataset.py --report /tmp/dataset-validation.json
python3 scripts/verify_fixtures.py --report /tmp/fixture-validation.json
python3 scripts/run_regression_tests.py
python3 scripts/verify_manifest.py --root .
```

The final downloadable ZIP has its own detached `.sha256` sidecar. To verify the archive as well as in-tree files, pass `--archive /path/to/STUDIO_KNOWLEDGE_003_checkpoint.zip`.

## Interpretation

A PASS here means schema/data integrity and the **three curated scenario contracts** validate. It does not mean an arbitrary brief can be selected automatically, every category is researched, tests/CI ran, any release occurred, or a standard is satisfied. API role-denial tests, AI trust/approval/recovery checks, and CLI filesystem tests are future evidence requirements; all relevant gates remain `INCOMPLETE` without candidate-bound results. Seven software types are explicitly `NOT_CALIBRATED`. See `reports/decision.md` for separate GO/PARTIAL/NO-GO decisions.
