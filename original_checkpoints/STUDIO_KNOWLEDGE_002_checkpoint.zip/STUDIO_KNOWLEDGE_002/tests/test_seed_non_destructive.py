import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]

class NonDestructiveSeedTest(unittest.TestCase):
    def digest_tree(self, root):
        return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted((root / 'dataset' / 'v1').glob('*.jsonl'))}

    def test_second_seed_preserves_enriched_dataset_and_is_cwd_independent(self):
        with tempfile.TemporaryDirectory(prefix='studio-knowledge-regression-') as td:
            sandbox = Path(td) / 'project'
            (sandbox / 'scripts').mkdir(parents=True)
            shutil.copy2(PROJECT / 'scripts' / 'seed_core.py', sandbox / 'scripts' / 'seed_core.py')
            shutil.copytree(PROJECT / 'dataset', sandbox / 'dataset')
            # Add an enrichment marker to a seeded record to detect destructive rewrites.
            path = sandbox / 'dataset' / 'v1' / 'prompt_patterns.jsonl'
            rows = [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
            rows[0]['category_specific']['test_enrichment_marker'] = 'preserve-me-exactly'
            path.write_text(''.join(json.dumps(r, sort_keys=True, ensure_ascii=False) + '\n' for r in rows))
            before = self.digest_tree(sandbox)
            # Invoke with an unrelated working directory; script resolves root from __file__.
            subprocess.run([sys.executable, str(sandbox / 'scripts' / 'seed_core.py')],
                           cwd=td, check=True, capture_output=True, text=True)
            after = self.digest_tree(sandbox)
            self.assertEqual(before, after, 'second seeding changed an enriched dataset file')
            enriched = [json.loads(x) for x in path.read_text().splitlines() if x.strip()][0]
            self.assertEqual(enriched['category_specific']['test_enrichment_marker'], 'preserve-me-exactly')

if __name__ == '__main__':
    unittest.main()
