#!/usr/bin/env python3
"""Explicitly version records when adding applicability and architecture metadata."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'dataset/v1'
changed={}
for filename in ['engineering_practices.jsonl','architecture_patterns.jsonl']:
 p=DATA/filename; rows=[json.loads(x) for x in p.read_text().splitlines() if x.strip()]; n=0; file_changed=False
 for r in rows:
  cs=r.setdefault('category_specific',{})
  before=json.dumps(cs,sort_keys=True)
  if r['knowledge_category']=='engineering_practices':
   val={'mandatory_status':'context_dependent','authority_condition':'Mandatory only when applicable law, regulation, contract, or adopted organizational policy says so; source guidance alone is not presumed binding.','omission_condition':'May be omitted or scaled when preconditions are absent, with rationale recorded.','decision_owner':'Project owner or relevant engineering/security authority per local governance.'}
   for k,v in val.items(): cs.setdefault(k,v)
  else:
   val={'alternatives':r.get('dependencies',[]),'tradeoffs':r.get('known_failure_modes',[]),'threat_assumptions':'Use only the assumptions supplied by the project; record unknown trust boundaries and risks.','complexity_cost':'Qualitative and context dependent; no cost or scale threshold is asserted.'}
   for k,v in val.items(): cs.setdefault(k,v)
  if json.dumps(cs,sort_keys=True)!=before:
   # Bump records that gained any new applicability/architecture fields only once.
   if r.get('version')=='1.0.0':r['version']='1.1.0'
   n+=1; file_changed=True
 if file_changed:p.write_text(''.join(json.dumps(r,sort_keys=True,ensure_ascii=False)+'\n' for r in rows))
 changed[filename]=n
print(json.dumps(changed,indent=2))
