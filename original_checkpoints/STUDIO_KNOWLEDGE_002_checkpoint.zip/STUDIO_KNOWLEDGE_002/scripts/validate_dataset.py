#!/usr/bin/env python3
"""Validate every populated dataset partition; path independent."""
from pathlib import Path
import argparse, json, sys
from jsonschema import Draft202012Validator, FormatChecker

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'dataset'/'v1'
SCHEMAS=ROOT/'schemas'
PARTITIONS=['software_types','engineering_practices','sdlc_stages','architecture_patterns','prompt_patterns','roadmap_patterns','verification_gates','reference_projects','sources','relationships']
KNOWLEDGE_PARTITIONS=set(PARTITIONS)-{'sources','relationships'}

def load_schema(file): return json.loads((SCHEMAS/file).read_text(encoding='utf-8'))
def read_jsonl(path):
 out=[]
 for n,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
  if not line.strip(): continue
  try: out.append((n,json.loads(line)))
  except Exception as e: raise ValueError(f'{path}:{n}: invalid JSON: {e}')
 return out

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--report',default=str(ROOT/'reports'/'validation-report.json')); args=ap.parse_args()
 schemas={'knowledge':load_schema('knowledge-record.schema.json'),'source':load_schema('source-record.schema.json'),'relationship':load_schema('relationship.schema.json')}
 validators={k:Draft202012Validator(v,format_checker=FormatChecker()) for k,v in schemas.items()}
 errors=[]; counts={}; rows={}; all_ids={}; kind_ids={}
 for part in PARTITIONS:
  f=DATA/(part+'.jsonl'); entries=read_jsonl(f) if f.exists() else []
  counts[part]=len(entries); rows[part]=entries; ids=set()
  typ='source' if part=='sources' else 'relationship' if part=='relationships' else 'knowledge'
  for line_no,obj in entries:
   for err in validators[typ].iter_errors(obj): errors.append({'file':str(f.relative_to(ROOT)),'line':line_no,'record_id':obj.get('id'),'message':err.message,'path':'/'.join(map(str,err.absolute_path))})
   rid=obj.get('id')
   if not rid: continue
   if rid in ids: errors.append({'file':str(f.relative_to(ROOT)),'line':line_no,'record_id':rid,'message':'duplicate ID within partition'})
   ids.add(rid)
   if rid in all_ids: errors.append({'file':str(f.relative_to(ROOT)),'line':line_no,'record_id':rid,'message':f'ID reused in {part}; first seen in {all_ids[rid]}'})
   else: all_ids[rid]=part
   if part in KNOWLEDGE_PARTITIONS: kind_ids.setdefault(part,set()).add(rid)
 # Applicable types are stable IDs, not labels.
 software_ids={obj.get('id') for _,obj in rows['software_types']}
 for part in KNOWLEDGE_PARTITIONS:
  for line_no,obj in rows[part]:
   for value in obj.get('applicable_software_types',[]):
    if value not in software_ids: errors.append({'file':f'dataset/v1/{part}.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'unknown applicable software type: {value}'})
 # Relationships must resolve both endpoints and source records; check typed predicates.
 endpoint_part={rid:p for p,vals in rows.items() for _,r in vals if (rid:=r.get('id'))}
 allowed={'applies_to':('software_types',KNOWLEDGE_PARTITIONS-{'software_types'}),'requires':(KNOWLEDGE_PARTITIONS,KNOWLEDGE_PARTITIONS),'verified_by':({'engineering_practices','sdlc_stages','architecture_patterns','prompt_patterns'}, {'verification_gates'}),'implemented_with':(KNOWLEDGE_PARTITIONS,{'reference_projects'}),'informs':(KNOWLEDGE_PARTITIONS,KNOWLEDGE_PARTITIONS),'produces':(KNOWLEDGE_PARTITIONS,KNOWLEDGE_PARTITIONS),'exemplified_by':({'software_types','reference_projects'}, {'reference_projects','sources'}),'supported_by':(KNOWLEDGE_PARTITIONS,{'sources'})}
 source_ids={obj.get('id') for _,obj in rows['sources']}
 for line_no,obj in rows['relationships']:
  for endpoint_key in ['source_endpoint','target_endpoint']:
   if obj.get(endpoint_key) not in endpoint_part: errors.append({'file':'dataset/v1/relationships.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'dangling {endpoint_key}: {obj.get(endpoint_key)}'})
  for sid in obj.get('source_ids',[]):
   if sid not in source_ids: errors.append({'file':'dataset/v1/relationships.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'dangling source_id: {sid}'})
  pred=obj.get('predicate'); pair=allowed.get(pred)
  if pair:
   left=endpoint_part.get(obj.get('source_endpoint')); right=endpoint_part.get(obj.get('target_endpoint'))
   if left not in pair[0] or right not in pair[1]: errors.append({'file':'dataset/v1/relationships.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'predicate {pred} does not allow endpoint types {left}->{right}'})
 for part in KNOWLEDGE_PARTITIONS|{'relationships'}:
  for line_no,obj in rows[part]:
   for sid in obj.get('source_ids',[]):
    if sid not in source_ids: errors.append({'file':f'dataset/v1/{part}.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'dangling source_id: {sid}'})
 # Roadmap example task graphs use local task IDs; validate their references and cycles.
 for line_no,obj in rows['roadmap_patterns']:
  tasks=obj.get('category_specific',{}).get('example_tasks',[])
  tids=[t.get('task_id') for t in tasks]
  if len(tids)!=len(set(tids)): errors.append({'file':'dataset/v1/roadmap_patterns.jsonl','line':line_no,'record_id':obj.get('id'),'message':'duplicate example task_id'})
  known=set(tids); graph={t.get('task_id'):t.get('depends_on',[]) for t in tasks}
  for tid,deps in graph.items():
   for dep in deps:
    if dep not in known: errors.append({'file':'dataset/v1/roadmap_patterns.jsonl','line':line_no,'record_id':obj.get('id'),'message':f'unknown task dependency {dep} in {tid}'})
  visiting=set();visited=set()
  def visit(node):
   if node in visiting:return True
   if node in visited:return False
   visiting.add(node)
   for dep in graph.get(node,[]):
    if dep in graph and visit(dep):return True
   visiting.remove(node);visited.add(node);return False
  if any(visit(n) for n in graph if n not in visited): errors.append({'file':'dataset/v1/roadmap_patterns.jsonl','line':line_no,'record_id':obj.get('id'),'message':'cyclic example task dependency'})
 report={'dataset_version':'1.0.0','schema_version':'1.0.0','counts':counts,'empty_partitions':[p for p,n in counts.items() if n==0],'record_count':sum(counts.values()),'error_count':len(errors),'errors':errors,'status':'PASS' if not errors else 'FAIL'}
 Path(args.report).parent.mkdir(parents=True,exist_ok=True); Path(args.report).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 print(json.dumps(report,indent=2,ensure_ascii=False)); return 0 if not errors else 1
if __name__=='__main__': sys.exit(main())
