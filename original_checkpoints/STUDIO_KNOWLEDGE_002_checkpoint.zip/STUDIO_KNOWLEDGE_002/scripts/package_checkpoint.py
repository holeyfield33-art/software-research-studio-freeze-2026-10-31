#!/usr/bin/env python3
"""Create a SHA-256 file manifest and a portable STUDIO-KNOWLEDGE-002 zip."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'STUDIO_KNOWLEDGE_002_checkpoint.zip'
validation=json.loads((ROOT/'reports'/'validation-report.json').read_text())
if validation.get('status')!='PASS' or validation.get('error_count')!=0:
 raise SystemExit('Refusing to package: final validation report is not PASS/zero errors')
include_dirs=['dataset','schemas','scripts','tests','reports','research']
files=[ROOT/'README.md']
for d in include_dirs:files.extend(p for p in (ROOT/d).rglob('*') if p.is_file())
files=sorted(set(files))
manifest={'project':'STUDIO-KNOWLEDGE-002','status':'PARTIAL','dataset_version':validation['dataset_version'],'schema_version':validation['schema_version'],'validation_status':validation['status'],'validation_errors':validation['error_count'],'record_counts':validation['counts'],'files_included':len(files)+1,'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'manifest_note':'This manifest excludes its own digest to avoid self-reference; a detached manifest SHA-256 sidecar is supplied. The ZIP hash is also detached. Original checkpoint ZIP is preserved separately and is not embedded.','original_checkpoint_sha256':(ROOT/'reports'/'original-checkpoint.sha256').read_text().strip().split()[0]}
mp=ROOT/'manifest.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files+[mp]:z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
for p,label in [(mp,ROOT.parent/'STUDIO_KNOWLEDGE_002_manifest.sha256'),(OUT,ROOT.parent/'STUDIO_KNOWLEDGE_002_checkpoint.sha256')]:
 label.write_text(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n',encoding='utf-8')
print(json.dumps({'archive':str(OUT),'archive_bytes':OUT.stat().st_size,'files':len(files)+1,'manifest':str(mp),'validation':'PASS'},indent=2))
