#!/usr/bin/env python3
"""Add concrete, hypothetical task-graph examples to roadmap pattern records."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; p=ROOT/'dataset/v1/roadmap_patterns.jsonl'
plans={
'roadmap.smallest_releasable_increment':[
 {'task_id':'inc.scope','title':'Confirm user outcome and acceptance evidence','depends_on':[],'dependency_type':'none','acceptance_criteria':['owner approves bounded behavior and non-goals'],'evidence_required':['versioned brief/decision']},
 {'task_id':'inc.build','title':'Implement one end-to-end usable slice','depends_on':['inc.scope'],'dependency_type':'mandatory','acceptance_criteria':['user outcome works in target context'],'evidence_required':['reviewed change linked to acceptance criteria']},
 {'task_id':'inc.verify','title':'Verify the candidate slice','depends_on':['inc.build'],'dependency_type':'mandatory','acceptance_criteria':['applicable required checks have actual results'],'evidence_required':['candidate-linked test/security outputs; unresolved items']},
 {'task_id':'inc.release','title':'Release or explicitly hold the increment','depends_on':['inc.verify'],'dependency_type':'mandatory_if_released','acceptance_criteria':['release authority decision and recovery path recorded'],'evidence_required':['artifact identity; approval; rollout/rollback evidence where applicable']}
],
'roadmap.dependency_aware_sequence':[
 {'task_id':'dep.discover','title':'List outcomes, constraints, and candidate tasks','depends_on':[],'dependency_type':'none','acceptance_criteria':['tasks are outcome-linked and bounded'],'evidence_required':['scope and assumptions']},
 {'task_id':'dep.map','title':'Classify hard prerequisites and optional enhancements','depends_on':['dep.discover'],'dependency_type':'mandatory','acceptance_criteria':['each dependency has a rationale and owner'],'evidence_required':['dependency graph with hard/optional labels']},
 {'task_id':'dep.prove','title':'Resolve highest-risk prerequisite or uncertainty','depends_on':['dep.map'],'dependency_type':'conditional','acceptance_criteria':['decision rule is met or uncertainty explicitly remains'],'evidence_required':['experiment/result or documented abstention']},
 {'task_id':'dep.deliver','title':'Deliver next feasible value slice','depends_on':['dep.map','dep.prove'],'dependency_type':'conditional','acceptance_criteria':['acceptance criteria and relevant gates are met'],'evidence_required':['candidate-linked verification and release evidence']}
],
'roadmap.risk_first_poc':[
 {'task_id':'poc.assumption','title':'Name material uncertainty and consequence','depends_on':[],'dependency_type':'none','acceptance_criteria':['uncertainty could invalidate a downstream commitment'],'evidence_required':['risk/assumption record']},
 {'task_id':'poc.design','title':'Define smallest discriminating experiment and stop rule','depends_on':['poc.assumption'],'dependency_type':'mandatory','acceptance_criteria':['observable result distinguishes decision options'],'evidence_required':['experiment plan and safety boundaries']},
 {'task_id':'poc.run','title':'Run the authorized experiment or mark blocked','depends_on':['poc.design'],'dependency_type':'conditional','acceptance_criteria':['result is observed or explicit blocker recorded'],'evidence_required':['actual output, environment and limits; never a fabricated result']},
 {'task_id':'poc.decision','title':'Choose proceed, rework, or stop','depends_on':['poc.run'],'dependency_type':'mandatory','acceptance_criteria':['decision follows the predeclared evidence rule'],'evidence_required':['decision record and updated roadmap']}
]}
rows=[json.loads(x) for x in p.read_text().splitlines() if x.strip()];changed=False
for r in rows:
 tasks=plans.get(r['id'])
 if tasks and r.get('category_specific',{}).get('example_tasks')!=tasks:
  r.setdefault('category_specific',{})['example_tasks']=tasks
  if r['version']=='1.0.0':r['version']='1.1.0'
  changed=True
if changed:p.write_text(''.join(json.dumps(r,sort_keys=True,ensure_ascii=False)+'\n' for r in rows))
print(json.dumps({'roadmap_patterns_enriched':sum(r['id'] in plans for r in rows)},indent=2))
