#!/usr/bin/env python3
"""Generate factual coverage/provenance reports from current dataset state."""
import csv,json,hashlib
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'dataset/v1'; REPORTS=ROOT/'reports'
parts=['software_types','engineering_practices','sdlc_stages','architecture_patterns','prompt_patterns','roadmap_patterns','verification_gates','reference_projects','sources','relationships']
rows={p:[json.loads(x) for x in (DATA/(p+'.jsonl')).read_text().splitlines() if x.strip()] for p in parts}
# Applicability matrix for knowledge partitions, plus sourced/project evidence and outgoing graph relationships.
types=rows['software_types']; types_by_id={r['id']:r for r in types}; knowledge=parts[:8]
matrix=[]
for t in types:
 tid=t['id']; out={'software_type_id':tid,'display_name':t['name']}
 for part in knowledge:
  out[part]=sum(tid in r.get('applicable_software_types',[]) for r in rows[part])
 out['reference_project_count']=sum(any(e['source_endpoint']==tid and e['target_endpoint']==r['id'] and e['predicate']=='exemplified_by' for e in rows['relationships']) for r in rows['reference_projects'])
 out['distinct_reachable_source_count']=len({e['target_endpoint'] for e in rows['relationships'] if e['source_endpoint']==tid and e['target_endpoint'].startswith('source.')})
 matrix.append(out)
fields=['software_type_id','display_name']+knowledge+['reference_project_count','distinct_reachable_source_count']
with open(REPORTS/'coverage-matrix.csv','w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(matrix)
# Per-partition required fields from schemas, actual absent values and explicit pending markers.
missing={}
for part in parts:
 schemafile='source-record.schema.json' if part=='sources' else 'relationship.schema.json' if part=='relationships' else 'knowledge-record.schema.json'
 sch=json.loads((ROOT/'schemas'/schemafile).read_text()); required=sch['required']; per=Counter()
 for r in rows[part]:
  for key in required:
   v=r.get(key)
   if key not in r or v is None or v=='': per[key]+=1
 missing[part]={'records':len(rows[part]),'required_field_missing_count':sum(per.values()),'required_field_observations':sum(len(required) for _ in rows[part]),'required_field_missing_percent':round(100*sum(per.values())/max(1,len(required)*len(rows[part])),2),'fields_missing':dict(per)}
REPORTS.joinpath('missing-fields-by-partition.json').write_text(json.dumps(missing,indent=2,ensure_ascii=False)+'\n')
# Pending source metadata by field.
sources=rows['sources']; pending_fields=['title','publisher','published_or_version_date','standard_version','repo_commit','file_path','claim_locator','claims_supported']
pending={k:sum(1 for s in sources if str(s.get(k,'')).lower().startswith('pending')) for k in pending_fields}
source_report={'source_record_count':len(sources),'pending_counts':pending,'pending_percent':{k:round(100*v/max(1,len(sources)),2) for k,v in pending.items()},'repository_records':[s['id'] for s in sources if s.get('repo_commit') not in ('not_applicable','pending')],'repo_files_without_pinned_commit':[s['id'] for s in sources if s.get('file_path') not in ('not_applicable','pending') and s.get('repo_commit') in ('not_applicable','pending')],'content_sha256_count':sum('content_sha256' in s for s in sources),'assessment':'Primary documentation and source files are favored. Repository file citations are commit-pinned. No content hashes or retained page snapshots are present; several living docs do not state publication dates, and one advisory page does not name a publisher.'}
REPORTS.joinpath('source-quality-report.json').write_text(json.dumps(source_report,indent=2,ensure_ascii=False)+'\n')
# Exact source-to-claim crosswalk (one row per record/source pair).
source_by_id={s['id']:s for s in sources}
with open(REPORTS/'provenance-claim-map.csv','w',newline='',encoding='utf-8') as f:
 w=csv.writer(f);w.writerow(['knowledge_record_id','record_version','knowledge_category','source_id','source_title','canonical_url','claim_locator','claim_supported','source_limitations'])
 for part in knowledge:
  for r in rows[part]:
   for sid in r.get('source_ids',[]):
    s=source_by_id.get(sid)
    if s:w.writerow([r['id'],r['version'],part,sid,s['title'],s['canonical_url'],s['claim_locator'],s['claims_supported'],s['limitations']])
# Evidence-strength summary: observed sources/configurations are not tests; no test outcome is inferred.
knowledge_records=[r for p in knowledge for r in rows[p]]
strength={'knowledge_record_count':len(knowledge_records),'records_with_source_ids':sum(bool(r.get('source_ids')) for r in knowledge_records),'observed_reference_project_records':sum(r['knowledge_category']=='reference_projects' for r in knowledge_records),'tested_outcome_records':sum('tested_outcome' in r.get('evidence_classification','').lower() for r in knowledge_records),'records_explicitly_marked_synthesis':sum('synthesis' in r.get('evidence_classification','').lower() for r in knowledge_records),'edge_evidence_counts':dict(Counter(e['evidence_classification'] for e in rows['relationships'])),'note':'Observed repository files, CI configuration, or tests present are not evidence of successful execution. No tested-outcome record is asserted.'}
REPORTS.joinpath('evidence-strength.json').write_text(json.dumps(strength,indent=2,ensure_ascii=False)+'\n')
# Graph degree, broken endpoint counts, and edge predicate counts.
node_ids=set()
for part in parts[:-1]:node_ids.update(r['id'] for r in rows[part])
degree=Counter()
for e in rows['relationships']:
 degree[e['source_endpoint']]+=1;degree[e['target_endpoint']]+=1
orphans=sorted(node for node in node_ids if degree[node]==0)
edge_report={'node_count':len(node_ids),'edge_count':len(rows['relationships']),'predicate_counts':dict(Counter(e['predicate'] for e in rows['relationships'])),'orphan_node_count':len(orphans),'orphan_nodes':orphans,'dangling_endpoint_count':sum(1 for e in rows['relationships'] for k in ('source_endpoint','target_endpoint') if e[k] not in node_ids),'broken_source_reference_count':sum(1 for e in rows['relationships'] for s in e['source_ids'] if s not in {x['id'] for x in sources})}
REPORTS.joinpath('graph-integrity.json').write_text(json.dumps(edge_report,indent=2,ensure_ascii=False)+'\n')
# Coverage narrative from computed records.
lines=['# Coverage matrix and explicit status','',f"Dataset contains {sum(len(rows[p]) for p in parts)} records across ten populated partitions. All categories have a category overview; detailed applicability is concentrated on the three required paper-trace verticals (AI agents, API/SaaS, CLI/library). The matrix counts applicable records, not empirical adequacy.",'','| Software type | Engineering practices | SDLC stages | Architecture | Prompts | Roadmaps | Gates | Reference projects |', '|---|---:|---:|---:|---:|---:|---:|---:|']
for r in matrix: lines.append(f"| {r['display_name']} | {r['engineering_practices']} | {r['sdlc_stages']} | {r['architecture_patterns']} | {r['prompt_patterns']} | {r['roadmap_patterns']} | {r['verification_gates']} | {r['reference_project_count']} |")
lines+=['','Counts identify applicability links only; they do not indicate tests passed or product maturity. `coverage-matrix.csv` includes source reachability counts.','']
REPORTS.joinpath('coverage-matrix.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'missing_fields':missing,'source_quality':source_report,'graph':edge_report},indent=2))
