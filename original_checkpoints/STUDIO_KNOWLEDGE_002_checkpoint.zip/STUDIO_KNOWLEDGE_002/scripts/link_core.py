#!/usr/bin/env python3
"""Idempotently append knowledge-evidence and workflow dependency edges."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'dataset/v1'
parts=['software_types','engineering_practices','sdlc_stages','architecture_patterns','prompt_patterns','roadmap_patterns','verification_gates','reference_projects']
records=[]
for part in parts:
 p=DATA/(part+'.jsonl')
 records.extend(json.loads(x) for x in p.read_text().splitlines() if x.strip())
path=DATA/'relationships.jsonl'; edges=[json.loads(x) for x in path.read_text().splitlines() if x.strip()]
existing={(e['source_endpoint'],e['target_endpoint'],e['predicate']) for e in edges}
initial_count=len(edges)
nextid=max([int(e['id'].split('.')[-1]) for e in edges]+[0])+1

def add(a,b,pred,scope,sources,evidence='synthesized_mapping'):
 global nextid
 if (a,b,pred) in existing:return
 edges.append({'id':f'edge.{nextid:04d}','version':'1.0.0','source_endpoint':a,'target_endpoint':b,'predicate':pred,'scope_qualifier':scope,'source_ids':list(dict.fromkeys(sources)),'evidence_classification':evidence})
 existing.add((a,b,pred));nextid+=1
# Every knowledge record's claim source is reachable as a typed edge.
for r in records:
 for sid in r.get('source_ids',[]):
  add(r['id'],sid,'supported_by','specific source claim locator; read limitations before applying', [sid], 'observed_implementation' if sid.startswith('source.') and any(token in sid for token in ['fastapi.','ripgrep.','agents.','saas.04','libraries.03','cli_tools.02']) else 'documented_guidance')
# Prompt structures explicitly map to relevant engineering practices and gates.
prompt_practices={
 'prompt.implement_scoped_task':['practice.requirements_traceability','practice.version_control_review','practice.test_strategy'],
 'prompt.add_test':['practice.test_strategy'],
 'prompt.review_change':['practice.version_control_review','practice.dependency_secret_handling'],
 'prompt.threat_model':['practice.threat_modeling'],
 'prompt.investigate_failure':['practice.test_strategy','practice.observability_incident'],
 'prompt.prepare_release':['practice.ci_reproducible_release','practice.change_maintenance']}
for pr, practices in prompt_practices.items():
 for practice in practices: add(pr,practice,'informs','prompt is a task contract; practice remains context-dependent',['source.nist.ssdf.v1_1','source.agents.instructions'] if pr.startswith('prompt.') else ['source.nist.ssdf.v1_1'])
# Roadmap patterns make verification prerequisites explicit rather than inventing calendar order.
roadmap_gates={
 'roadmap.smallest_releasable_increment':['gate.requirements_acceptance','gate.unit_integration_execution','gate.release_readiness'],
 'roadmap.dependency_aware_sequence':['gate.requirements_acceptance','gate.dependency_provenance','gate.release_readiness'],
 'roadmap.risk_first_poc':['gate.security_risk_review','gate.unit_integration_execution']}
for rd,gates in roadmap_gates.items():
 for gate in gates: add(rd,gate,'requires','apply only when the named verification gate is in scope; otherwise record exclusion',['source.scrum.guide.2020','source.nist.ssdf.v1_1'])
# Architecture pattern applicability that crosses the three demonstration slices.
for typ in ['software_type.web_applications','software_type.saas','software_type.apis','software_type.mobile_applications','software_type.cli_tools','software_type.developer_tools','software_type.ai_agents','software_type.security_products','software_type.data_pipelines','software_type.libraries']:
 add(typ,'arch.minimal_viable_structure','applies_to','consider as a selection principle; do not impose a particular stack',['source.aws.segment_workload','source.12factor.processes'])
for typ in ['software_type.saas','software_type.apis','software_type.data_pipelines','software_type.ai_agents']:
 add(typ,'arch.event_queue','applies_to','only if deferrable/asynchronous work or independent pacing is required',['source.google.microservices_intro'])
path.write_text(''.join(json.dumps(e,ensure_ascii=False,sort_keys=True)+'\n' for e in edges),encoding='utf-8')
print(json.dumps({'relationships_total':len(edges),'new_relationships':len(edges)-initial_count},indent=2))
