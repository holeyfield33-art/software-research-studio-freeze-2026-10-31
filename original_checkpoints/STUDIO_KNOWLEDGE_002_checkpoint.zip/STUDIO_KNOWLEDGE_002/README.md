# STUDIO-KNOWLEDGE-002

This is a research checkpoint for a future structured repository and generator. It contains data, evidence, schemas, validation and reports only; it does not implement a generator or alter Studio, Block-Wise, production products, or existing repositories.

## Status

The integrated data slice is **PARTIAL** overall. Dataset integrity checks pass: all ten JSONL partitions are populated; the current Draft 2020-12 validator reports zero errors; there are no duplicate IDs, dangling references, type-invalid edges, or orphan nodes. The non-destructive seed regression test passes. This does not establish that any example repository, hypothetical project, prompt, roadmap, deployment or product passes tests or is production ready.

## Contents

`dataset/v1/` contains the ten JSONL partitions. `schemas/` contains the knowledge-record, source-record and relationship schemas. `reports/` contains research synthesis, coverage matrix and gaps, source-quality/evidence reports, data dictionary, validation and missing-field reports, conflict cases, paper trace exercises, change log, blockers, and checkpoint provenance. `research/` retains the source-normalization results and the inherited source inventory used in migration. `scripts/` contains additive seed, migration, enrichment, linking, validation and report-generation tools. `tests/` tests seed idempotence and preservation of enrichment.

## Safe commands

From any current working directory, run:

```bash
python3 /absolute/path/STUDIO_KNOWLEDGE_002/scripts/validate_dataset.py
python3 -m unittest discover -s /absolute/path/STUDIO_KNOWLEDGE_002/tests -v
python3 /absolute/path/STUDIO_KNOWLEDGE_002/scripts/seed_core.py
```

The validator requires `jsonschema` (Draft 2020-12); this workspace's `.venv` installs it. The seed uses paths relative to its own script, creates missing partition files without truncating existing ones, requires an initialized non-empty software-type partition, and only appends IDs not already present. Enrichment/import tools are version-aware; rerunning against already-versioned records does not overwrite them. Run the seed regression test before accepting future seeder changes.

## Evidence rules

Source IDs are stable. Source and knowledge record versions are semantic-version strings. `pending` means the cited page did not establish that metadata; it is not guessed. Repository file sources are commit-pinned. Observed repository files and workflow configuration are not successful test results. Verification gates return `INCOMPLETE` when scope, candidate identity, authority, or execution evidence is missing. Organization-specific policy, risk thresholds, regulatory applicability, project scope, and calendar estimates must come from an actual brief or accountable owner.

See `reports/research-report.md` first, then `reports/traceability-exercises.md`, `reports/coverage-gaps.md`, and `reports/next-blockers.md`.
