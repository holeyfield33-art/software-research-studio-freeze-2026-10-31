# Paper traceability exercises

These are paper exercises over the knowledge records, not generated Studio outputs and not implementation/test results. The example briefs are hypothetical. Recommendations below are conditional on the stated assumptions.

## A. AI agent with tool access

**Brief assumptions:** networked agent receives user and retrieved content; it can call read tools and a limited write tool; write effects are consequential but reversible; no high-risk domain is specified.

**Trace:** `software_type.ai_agents` and `software_type.security_products` → `sdlc.requirements_risk`, `sdlc.architecture_design`, `sdlc.implementation`, `sdlc.verification`, `sdlc.release`, `sdlc.maintenance_feedback` → `practice.threat_modeling`, `practice.dependency_secret_handling`, `practice.test_strategy`, `practice.ci_reproducible_release`, `practice.observability_incident` → `arch.agent_tool_boundary` → `gate.security_risk_review`, `gate.unit_integration_execution`, `gate.dependency_provenance`, `gate.release_readiness`, `gate.operational_rollback` → prompt contracts `prompt.threat_model`, `prompt.implement_scoped_task`, `prompt.add_test`, `prompt.review_change`, `prompt.investigate_failure`, `prompt.prepare_release` → roadmap patterns `roadmap.risk_first_poc` and `roadmap.dependency_aware_sequence` → reference `reference.openai_agents_sdk`.

**Deliverables/evidence:** bounded tool inventory and authorization rules; threat model with untrusted-input and side-effect paths; scoped implementation diff; actual unit/integration results bound to candidate revision; dependency/provenance evidence if required; approval record for high-impact actions; rollback/disable path; operational log/retention decision. Source IDs include `source.owasp.tm.cheatsheet`, `source.nist.ssdf.v1_1`, `source.agents.policy`, `source.agents.instructions`, `source.agents.test`, and `source.agents.ci`.

**Rejected/inapplicable:** multi-agent orchestration, persistent memory, vector database, cloud deployment, and event queues are not implied by “agent.” Add them only if task continuity, retrieval, scale, or independent work warrants them. No claim that OpenAI Agents SDK tests or CI passed; those files were observed, not executed.

## B. Small authenticated API

**Brief assumptions:** one service exposes a small HTTP API with user authentication and persisted records; no multi-tenant organization requirements, high availability target, or regulated data is specified.

**Trace:** `software_type.apis` and `software_type.web_applications` → `sdlc.discovery_scope`, `sdlc.requirements_risk`, `sdlc.architecture_design`, `sdlc.implementation`, `sdlc.verification`, `sdlc.release` → `practice.requirements_traceability`, `practice.version_control_review`, `practice.dependency_secret_handling`, `practice.test_strategy`, `practice.threat_modeling`, `practice.ci_reproducible_release` → `arch.client_server_api_boundary` and (if complexity benefits) `arch.layered_modular` → gates `gate.requirements_acceptance`, `gate.security_risk_review`, `gate.unit_integration_execution`, `gate.dependency_provenance`, `gate.release_readiness` → prompts `prompt.implement_scoped_task`, `prompt.add_test`, `prompt.review_change`, `prompt.threat_model`, `prompt.investigate_failure`, `prompt.prepare_release` → `roadmap.smallest_releasable_increment` and `roadmap.dependency_aware_sequence` → `reference.fastapi`.

**Deliverables/evidence:** API contract; explicit authentication and server-side authorization rules; data model/migration if persistence is confirmed; tests for authorized and unauthorized paths; dependency review; candidate-linked test outputs; release artifact identity and rollback decision. Source IDs include `source.apis.01`, `source.apis.02`, `source.apis.03`, `source.nist.ssdf.v1_1`, `source.fastapi.tests`, and `source.fastapi.ci`.

**Rejected/inapplicable:** multitenancy isolation is not assigned as a mandatory pattern absent tenant/org boundaries. Microservices, queues, Kubernetes, and a separate gateway are not implied by a small API. Authentication is in the brief; a particular identity protocol or provider is not selected without requirements. CI configuration is not evidence of passing CI.

## C. Offline CLI negative control

**Brief assumptions:** one local executable processes user-supplied files, works offline, stores no shared/server data, has no user accounts, and performs no destructive writes in the first increment.

**Trace:** `software_type.cli_tools` (optional related library record `software_type.libraries`) → `sdlc.discovery_scope`, `sdlc.requirements_risk`, `sdlc.implementation`, `sdlc.verification`, `sdlc.release`, `sdlc.maintenance_feedback` → `practice.requirements_traceability`, `practice.version_control_review`, `practice.dependency_secret_handling`, `practice.test_strategy`, `practice.ci_reproducible_release`, `practice.change_maintenance` → `arch.minimal_viable_structure` (use direct executable or modular core only as needed) → gates `gate.requirements_acceptance`, `gate.unit_integration_execution`, `gate.dependency_provenance`, `gate.release_readiness` → prompts `prompt.implement_scoped_task`, `prompt.add_test`, `prompt.review_change`, `prompt.investigate_failure`, `prompt.prepare_release` → `roadmap.smallest_releasable_increment` → `reference.ripgrep`.

**Deliverables/evidence:** command/argument/output/exit-status contract; file fixtures; unit and executable-level tests; supported OS/package targets; built artifact and release checksums/signing if risk warrants; install/upgrade instructions. Source IDs include `source.cli_tools.01`, `source.cli_tools.03`, `source.cli_tools.04`, `source.ripgrep.regression`, and `source.ripgrep.release`.

**Rejected/inapplicable:** no database, authentication, multitenancy, cloud deployment, container platform, API gateway, or queue is assigned. Offline/local file handling can still need permission and path-safety controls if write behavior is introduced. `gate.operational_rollback` and service observability are omitted absent a deployed service; user diagnostics and safe reruns remain relevant.

## Trace limitations

The record graph supports the major paths, but the three exercises remain human-authored paper mappings. The knowledge base does not infer project-specific acceptance criteria, jurisdiction, risk tolerance, hosting, team roles, or estimated dates. Each requires project inputs and accountable human decisions. Missing execution artifacts yield `INCOMPLETE`, not a passing gate.
