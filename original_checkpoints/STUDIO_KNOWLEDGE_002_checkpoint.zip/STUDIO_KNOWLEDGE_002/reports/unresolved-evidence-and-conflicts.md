# Unresolved evidence and conflict cases

## Stack-specific guidance

Android architecture guidance recommends layered UI/data boundaries and lifecycle-aware state for Android applications (`source.mobile_applications.01`). The Twelve-Factor Processes guidance recommends stateless/share-nothing processes with durable state in backing services (`source.12factor.processes`). These statements are not treated as a conflict: they address different concerns and scopes. Neither is imposed on an offline CLI or every application. Remaining decision: select platform- and requirement-specific layers, state ownership, and storage from the actual product brief; the dataset does not establish a universal stack or cost threshold.

## Changed or superseded source

The ISO/IEC/IEEE 12207:2017 catalog record is marked withdrawn/superseded by the 2026 edition in `source.iso.12207.2026.summary`; the full current normative text was not reviewed. Separately, the SP 800-53 Rev. 5 Update 1 URL notes a later Release 5.2.0. Historical claims remain scoped to the cited edition; the current normative requirements and adoption status are unresolved. Before a generator uses either as a current compliance basis, obtain and inspect the applicable full edition and determine the organization’s adoption/tailoring.

## Missing test-result artifact

FastAPI, ripgrep, and OpenAI Agents SDK repositories contain test source and CI/release workflow configuration at pinned commits. No test command or workflow run was executed or retrieved for this research. Therefore any gate asking whether repository tests passed must return `INCOMPLETE`, not `PASS`; a test file, CI workflow, published guideline, or paper trace is not a run artifact. A future evidence record should include candidate SHA or artifact digest, exact command/workflow run, environment, timestamp, result, and failure triage.

## Additional unresolved items

Some primary documents are living web pages without published/revision dates; metadata remains explicitly pending. Remote content hashes/snapshots are absent. No organization-specific risk threshold, approval authority, regulatory mapping, capacity history, service objective, or calendar estimate was supplied. Those details must remain unresolved rather than be invented.
