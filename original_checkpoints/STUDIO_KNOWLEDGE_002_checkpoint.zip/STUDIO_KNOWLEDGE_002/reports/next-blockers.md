# Next blockers before reliable generator use

1. Resolve source dates that are not stated on source pages, and verify the one publisher pending only if an authoritative publisher can be established. Keep `pending` otherwise.
2. Decide whether source snapshots or content hashes may be retained for each source type, subject to licensing and operational policy; none are currently stored.
3. Obtain the full, applicable current ISO/IEC/IEEE 12207 text and authoritative adoption/tailoring details before presenting its lifecycle guidance as current normative criteria. Confirm the applicable SP 800-53 revision where it is used.
4. Obtain project-specific role/approval policy, regulatory scope, risk acceptance thresholds, operational targets, supported deployment model, and test evidence. These cannot be inferred from the present general knowledge base.
5. Expand detailed applicability and reference evidence beyond the AI-agent/security, web/API/SaaS, and CLI/library slices. The other seven categories have overview records but not comparable complete paper exercises.
6. Run actual tests or retrieve signed/traceable CI results for any candidate project being used as a tested-outcome reference. Until then, gates remain incomplete.
7. Review record content and the human-authored graph mappings with engineering/security owners before importing into any generator. The current graph encodes research mappings, not validated product policy.
