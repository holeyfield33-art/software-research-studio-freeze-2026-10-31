# Coverage matrix and explicit status

Dataset contains 522 records across ten populated partitions. All categories have a category overview; detailed applicability is concentrated on the three required paper-trace verticals (AI agents, API/SaaS, CLI/library). The matrix counts applicable records, not empirical adequacy.

| Software type | Engineering practices | SDLC stages | Architecture | Prompts | Roadmaps | Gates | Reference projects |
|---|---:|---:|---:|---:|---:|---:|---:|
| Web applications | 8 | 7 | 4 | 6 | 3 | 6 | 0 |
| SaaS products | 8 | 7 | 5 | 6 | 3 | 6 | 1 |
| APIs and web services | 8 | 7 | 5 | 6 | 3 | 6 | 1 |
| Mobile applications | 5 | 7 | 3 | 6 | 3 | 4 | 0 |
| CLI tools | 6 | 7 | 1 | 6 | 3 | 4 | 1 |
| Developer tools | 5 | 7 | 3 | 6 | 3 | 4 | 0 |
| AI agents | 8 | 7 | 3 | 6 | 3 | 6 | 1 |
| Security products | 8 | 7 | 2 | 6 | 3 | 6 | 1 |
| Data pipelines | 5 | 7 | 2 | 6 | 3 | 4 | 0 |
| Libraries and SDKs | 6 | 7 | 2 | 6 | 3 | 4 | 1 |

Counts identify applicability links only; they do not indicate tests passed or product maturity. `coverage-matrix.csv` includes source reachability counts.
