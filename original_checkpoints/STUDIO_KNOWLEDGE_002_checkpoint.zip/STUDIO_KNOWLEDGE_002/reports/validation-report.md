# Validation report

The complete Draft 2020-12 validator ran against all ten JSONL partitions. Result: **PASS** with zero JSON Schema violations, duplicate IDs, dangling knowledge/source references, dangling relationship endpoints, or relationship endpoint-type violations. All records use schema-valid version syntax and all applicability fields resolve to stable software-type IDs. The empty-partition list is empty.

Partition counts and total relationship/source counts are in `validation-report.json`. The graph-integrity report records 0 orphan nodes, 0 dangling endpoints, and 0 broken source references. The machine-readable missing-field report records 0% absent required fields in each partition; this checks field presence, not whether a field marked `pending` is sufficiently complete for a particular downstream use.

The non-destructive seeder regression test passed from an unrelated current working directory. It verified that a second run left enriched JSONL bytes unchanged. Repository test files were not executed; this report validates the research dataset and seed-tool behavior only, not any product implementation, sample repository, Studio output, or production readiness.
