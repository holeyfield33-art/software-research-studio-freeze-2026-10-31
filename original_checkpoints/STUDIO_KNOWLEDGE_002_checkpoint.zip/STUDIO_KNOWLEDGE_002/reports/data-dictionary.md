# Data dictionary and migration notes

Dataset version `1.0.0`; schema version `1.0.0`; JSONL is UTF-8, one JSON object per non-empty line. Stable IDs are retained across record revisions. `version` tracks record revisions using `major.minor.patch`; changing meanings or stable foreign keys requires explicit version changes and a change-log entry. Empty partitions are represented by present zero-byte files and explicitly listed in validation reports.

## Knowledge records

- `id`: stable foreign key, namespaced by record type.
- `version`: revision of the record content.
- `knowledge_category`: partition name.
- `applicable_software_types`: identifiers of records in `software_types.jsonl`, not display labels.
- `preconditions_and_exclusions`: circumstances where the practice applies, must be adapted, or should be omitted.
- `required_inputs`: project evidence needed before using the guidance.
- `recommended_actions_or_practices`: conditional actions, not universal mandates.
- `dependencies`: prerequisite decisions or components.
- `expected_deliverables`: expected artifacts or evidence.
- `verification_requirements`: observable criteria for checking adoption or outcome.
- `known_failure_modes`: risks and ways the pattern can fail.
- `source_ids`: foreign keys to source records.
- `evidence_classification`: distinguishes official documented guidance, observed repository state, tested outcomes, and synthesis. Repository files/workflow definitions are not test outcomes.
- `confidence`, `limitations`: qualitative confidence and explicit scope boundaries.
- `related_record_ids`: reserved for direct links; the relationship graph is canonical for typed edges.
- `category_specific`: typed-by-convention extension object for stage entry/exit/rework, prompt variables/contracts, gate outcomes, roadmap assumptions, or reference-project details.

## Source records

Sources carry stable ID/version, actual title/publisher, canonical URL, retrieval and publication/version dates, standard version, commit and file path for repository evidence, source type, precise claim locator, claims supported, limitations, and optional content hash. Unknown metadata is written as `pending`; non-repository fields use `not_applicable`. Repository file citations must use a commit-pinned URL and record `repo_commit` and `file_path`. `content_sha256` is optional and not yet populated for remote sources.

## Relationship records

Relationship records are typed graph edges, not knowledge-envelope rows. Each has a stable edge ID, version, source/target endpoint IDs, a controlled predicate, a scope qualifier, source IDs, and evidence classification. Predicates include `applies_to`, `requires`, `verified_by`, `implemented_with`, `informs`, `produces`, `exemplified_by`, and `supported_by`. Validator enforces endpoint existence, selected type constraints, and source references.

## Evidence categories

`documented_guidance` means the source states guidance or a requirement. `observed_implementation` means a repository file or configuration was inspected. `tested_outcome` is reserved for a test actually executed and tied to a candidate; no record currently claims this for the reference projects. `synthesized_mapping` indicates a graph or applicability mapping inferred for this dataset and must not be presented as a source quotation or tested fact.

## Migration

The inherited source rows were versioned from `1.0.0` to `1.1.0` without changing stable IDs. Their original URLs and claim text are replaced by inspected source metadata/locators. The ten software-type records retain IDs and are versioned to `1.1.0` to make `applicable_software_types` self-referential stable IDs. Newly added records begin at `1.0.0`; graph edges use `edge.NNNN` stable IDs. The initial checkpoint ZIP remains unchanged and is preserved separately.
