# Change log

- 2026-10-30: Started STUDIO-KNOWLEDGE-002 in a separate workspace. Imported a copy of the original checkpoint's JSONL partitions. Original ZIP SHA-256 recorded as `30a2cd7746064c36ea24b7e43c302942db6e10b674edcc06de7ced7f97a4732c`. The original ZIP is not modified.
- Safety note: `build_seed.py` from the imported archive is retained only as historical evidence and must not be run; continuation tooling will be non-destructive and operate in this workspace.
- 2026-10-30: Added Draft 2020-12 knowledge, source, and relationship schemas; source fields include actual title/publisher, canonical URL, retrieval/publication/version metadata, commit/file path, locator, claims, and limitations. Added typed predicate and endpoint validation.
- 2026-10-30: Versioned 35 inherited source records to 1.1.0 with verified claim locators, precise supported claims, limitations, and pinned repository-file commits where applicable. Preserved their stable IDs. Versioned software-type records to 1.1.0 so applicability foreign keys are stable IDs.
- 2026-10-30: Added 39 cross-cutting stage/practice/architecture/gate/prompt/roadmap/reference records; added 27 additional source records; and populated typed graph paths. No tested outcomes were asserted.
- 2026-10-30: Full Draft 2020-12 validation reports zero errors; all 10 partitions populated. Seed regression test passed, including second-run byte preservation of enriched JSONL data from an unrelated working directory.
- Remaining: Remote content hashes/snapshots are not stored; some source publication/version dates and one publisher are pending; no sample repository test/CI run was executed; current normative standard text/adoption and project-specific risk/approval inputs need follow-up.
